import random
from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit, join_room, leave_room

app = Flask(__name__)
socketio = SocketIO(app)

game_data = {
    'players': {},
    'guesses': [],
    'correct_answer': random.randint(1, 100)
}

@app.route('/')
def index():
    return render_template('guess_game.html')

@socketio.on('join')
def on_join(data):
    player_name = data['name']
    player_id = request.sid
    game_data['players'][player_id] = {'name': player_name, 'score': 0, 'guesses': 0}
    emit('player_joined', {'players': game_data['players'], 'guesses': game_data['guesses']}, broadcast=True)
    print(f"Player joined: {player_name}")

@socketio.on('guess')
def on_guess(data):
    player_id = request.sid
    guess = data['guess']
    player = game_data['players'][player_id]
    player['guesses'] += 1
    hint = generate_hint(guess)

    new_guess = {'player': player['name'], 'guess': guess, 'hint': hint}
    game_data['guesses'].insert(0, new_guess)

    emit('new_guess', new_guess, broadcast=True)
    print(f"Guess received: {player['name']} guessed {guess}, hint: {hint}")

    if guess == game_data['correct_answer']:
        player['score'] += 1
        emit('correct_answer', {'player_name': player['name'], 'correct_answer': guess}, broadcast=True)
        start_new_round()
    else:
        emit('game_update', {'players': game_data['players'], 'guesses': game_data['guesses']}, broadcast=True)

def generate_hint(guess):
    if guess < game_data['correct_answer']:
        return 'Too low'
    elif guess > game_data['correct_answer']:
        return 'Too high'
    return 'Correct!'

def start_new_round():
    game_data['guesses'] = []
    game_data['correct_answer'] = random.randint(1, 100)
    emit('new_round_update', {'players': game_data['players'], 'guesses': game_data['guesses'], 'answer': game_data['correct_answer']}, broadcast=True)
    print("New round started")

if __name__ == '__main__':
    socketio.run(app, debug=True)