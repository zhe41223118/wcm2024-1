from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit, join_room
import random

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret_key'
socketio = SocketIO(app)

# 儲存遊戲狀態和玩家資訊
games = {}

@app.route('/')
def index():
    return render_template('index_v6.html')

@socketio.on('join')
def on_join(data):
    room = data.get('room')
    name = data.get('name')
    player_id = request.sid

    if player_id is None:
        emit('error', {'message': 'Invalid player ID'})
        return

    join_room(room)

    if room not in games:
        games[room] = {
            'answer': random.randint(1, 100),
            'players': {}
        }

    games[room]['players'][player_id] = {'name': name, 'score': 0, 'guesses': 0, 'lost': False}

    emit('player_joined', {'players': games[room]['players']}, room=room)

@socketio.on('guess')
def on_guess(data):
    room = data.get('room')
    guess = data.get('guess')
    player_id = request.sid

    game = games[room]
    answer = game['answer']
    players = game['players']
    player_name = players[player_id]['name']

    # 檢查玩家是否已經輸掉
    if players[player_id]['lost']:
        return  # 不處理猜測

    if players[player_id]['guesses'] >= 9:
        # 玩家已達猜測上限，標記為輸家
        players[player_id]['lost'] = True
        emit('game_lost', {'player_id': player_id, 'player_name': player_name}, room=room)
        return

    if guess == answer:
        # 玩家猜對
        players[player_id]['score'] += 1
        players[player_id]['guesses'] = 0
        correct_answer = answer
        new_answer = random.randint(1, 100)
        games[room]['answer'] = new_answer
        emit('game_update', {'players': players, 'correct_answer': correct_answer}, room=room)
        emit('correct_answer', {'player_id': player_id, 'correct_answer': correct_answer, 'player_name': player_name}, room=room)

        all_correct = all(player['score'] > 0 for player in players.values())
        if all_correct:
            games[room] = {
                'answer': new_answer,
                'players': {pid: {'name': player['name'], 'score': 0, 'guesses': 0, 'lost': False} for pid, player in players.items()}
            }
            emit('new_round', {'players': games[room]['players'], 'answer': new_answer, 'room': room}, room=room)
    else:
        # 玩家猜錯
        players[player_id]['guesses'] += 1
        emit('guess_update', {'players': players, 'player_name': player_name}, room=room)
        emit('hint', {'hint': 'Too low' if guess < answer else 'Too high', 'player_name': player_name}, room=room)

if __name__ == '__main__':
    socketio.run(app, host='120.113.99.64', port=80, debug=True)