from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit, join_room
import random

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret_key'
socketio = SocketIO(app)

# 儲存遊戲狀態和玩家資訊
games = {}

@app.route('/')
def index():
    return render_template('index_v1.html')

@socketio.on('join')
def on_join(data):
    room = data.get('room')
    join_room(room)

    # 如果房間不存在,則創建新遊戲
    if room not in games:
        games[room] = {
            'answer': random.randint(1, 100),
            'players': []
        }

    # 將玩家加入遊戲
    games[room]['players'].append(request.sid)

    # 通知所有玩家新玩家加入
    emit('player_joined', {'player_id': request.sid}, room=room)

@socketio.on('guess')
def on_guess(data):
    room = data.get('room')
    guess = data.get('guess')
    player_id = request.sid

    game = games[room]
    answer = game['answer']

    if guess == answer:
        # 玩家猜對,更新遊戲狀態並通知所有玩家
        emit('game_won', {'player_id': player_id}, room=room)
        games[room] = {
            'answer': random.randint(1, 100),
            'players': game['players']
        }
    elif guess < answer:
        emit('hint', {'hint': 'Too low', 'player_id': player_id}, room=room)
    else:
        emit('hint', {'hint': 'Too high', 'player_id': player_id}, room=room)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)