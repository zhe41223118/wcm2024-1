from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit, join_room
import random

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret_key'
socketio = SocketIO(app)

# 儲存遊戲狀態和玩家資訊
games = {}

@app.route('/')
def index():
    return render_template('index_v3.html')

@socketio.on('join')
def on_join(data):
    room = data.get('room')
    name = data.get('name')
    player_id = request.sid

    if player_id is None:
        # 處理無效的玩家ID
        emit('error', {'message': 'Invalid player ID'})
        return

    join_room(room)

    # 如果房間不存在,則創建新遊戲
    if room not in games:
        games[room] = {
            'answer': random.randint(1, 100),
            'players': {}
        }

    # 將玩家加入遊戲
    games[room]['players'][player_id] = {'name': name, 'score': 0, 'guesses': 0}

    # 通知所有玩家新玩家加入
    emit('player_joined', {'players': games[room]['players']}, room=room)

@socketio.on('guess')
def on_guess(data):
    room = data.get('room')
    guess = data.get('guess')
    player_id = request.sid

    game = games[room]
    answer = game['answer']
    players = game['players']

    if guess == answer:
        # 玩家猜對,重置該玩家分數和猜測次數,並生成新的答案數字
        players[player_id]['score'] += 1
        players[player_id]['guesses'] = 0
        games[room]['answer'] = random.randint(1, 100)
        emit('game_update', {'players': players, 'answer': games[room]['answer']}, room=room)

        # 檢查是否所有玩家都猜對,如果是,重置遊戲
        all_correct = all(player['score'] > 0 for player in players.values())
        if all_correct:
            games[room] = {
                'answer': random.randint(1, 100),
                'players': {pid: {'name': player['name'], 'score': 0, 'guesses': 0} for pid, player in players.items()}
            }
            emit('new_round', games[room], room=room)
    else:
        players[player_id]['guesses'] += 1
        emit('guess_update', {'players': players}, room=room)
        emit('hint', {'hint': 'Too low' if guess < answer else 'Too high', 'player_id': player_id}, room=room)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)